var friendsArray = [{
  "name": "Vincent Visconti",
  "photo": "http://www.vivi.guru/assets/images/ProPic.jpg",
  "scores": [
    "1",
    "1",
    "5",
    "1",
    "5",
    "4",
    "5",
    "1",
    "4",
    "5"
  ]
},
{
  "name": "Maximus Decimus Meridius",
"photo": "http://vignette2.wikia.nocookie.net/gladiator2000/images/9/90/Maximus_Decimus_Meridius.jpg",
"scores": [
"5",
"3",
"4",
"1",
"5",
"1",
"5",
"3",
"4",
"2"
  ]
},
{
  "name": "William Wallace",
  "photo": "http://www.monologuedb.com/wp-content/uploads/2011/01/braveheart.jpg",
  "scores": [
    "5",
    "2",
    "2",
    "2",
    "4",
    "1",
    "3",
    "2",
    "5",
    "5"
  ]
},
{
  "name": "Lloyd Christmas",
  "photo": "http://3.bp.blogspot.com/-Bl-Dhb9ZYLc/TwEnAdeepdI/AAAAAAAALJI/vqiTe7S4_t0/s1600/jim+carrey.jpg",
  "scores": [
    "3",
    "3",
    "4",
    "2",
    "2",
    "1",
    "3",
    "2",
    "2",
    "3"
  ]
},
{
  "name": "Harry Dunne",
  "photo": "https://s-media-cache-ak0.pinimg.com/564x/ca/b2/65/cab2651567d8b66343bc2271ec793b03.jpg",
  "scores": [
    "4",
    "3",
    "4",
    "1",
    "5",
    "2",
    "5",
    "3",
    "1",
    "4"
  ]
},
{
  "name": "Michael Scott",
  "photo": "http://68.media.tumblr.com/dc1828fa22136fdef3af486add7a2aed/tumblr_inline_nopuhdnvKd1tuzcai_500.jpg",
  "scores": [
    "4",
    "4",
    "2",
    "3",
    "2",
    "2",
    "3",
    "2",
    "4",
    "5"
  ]
},
{
  "name": "Tyrion Lannister",
  "photo": "https://pbs.twimg.com/profile_images/668279339838935040/8sUE9d4C.jpg",
  "scores": [
    "4",
    "5",
    "2",
    "2",
    "3",
    "2",
    "5",
    "4",
    "5",
    "5"
  ]
}
];

module.exports = friendsArray;